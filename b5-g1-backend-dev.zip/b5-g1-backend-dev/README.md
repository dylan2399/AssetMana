#B5-G1-BACKEND

The backend of Asset Management System

1. We have 3 main applications which are: dev (For Developer), prod (Not using yet) and test (For Tester). You can set default in 
application.properties such as: spring.profiles.active=dev/prod/test.

2. Input username, password of your MySQL workbench account (Or any tool to login to MySQL server).
--for example: 	spring.datasource.username=root
		spring.datasource.password=Ni1219
in application-dev.properties.

3. Then run project in Intellij or Eclipse with JDK 11 (Java version 11 suggesting).

