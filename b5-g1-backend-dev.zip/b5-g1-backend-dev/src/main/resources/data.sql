USE `asset-management`;
INSERT INTO `user`
(staff_code, dob, is_first_login, fname, gender, type, joined_date, lname, password, username, location, status)
VALUES ('SD0001', '2000-06-01', true, 'Du', 'Male', 'ADMIN', '2021-08-06', 'Tran Hai',
        '$2a$10$BvyFlF6PYr3xlznu3NUrUuFPPqkgJ/zpygQtAv34./mrsM/9dg05u', 'duth', 'Hanoi', 'ENABLE');